# CS612-Assignment3-Part2

- In this part, we're practicing Junit testing. We are to follow along to a youtube video and implemement the JUnit correctly, meaning it should run when someone downloads these files. 

# How to Run
 
 - Uses JUnit4, so set that up in IntelliJ or Eclipse.
  - Then you can run the files using the run button and see your test results, which should all pass.
