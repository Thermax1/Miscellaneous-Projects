# Hash Tables and Arrays via Leetcode

- Leetocde 217: Contains Duplicate
    - Brute force is O(n^2) time but O(1) space
    - Sort it, which O(nlogn) time and O(1) space
        - Compare adjacents
    - HashSet, which is O(n) time, but space is O(n)
        - Uses more memory.
        - Check to see if in hashset, add to set if not