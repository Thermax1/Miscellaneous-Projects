class Node: # created so we don't have to create the node each time within the functions below that create nodes. Just call this.
    # Use self. when you have variables that apply to a specific instance
    def __init__(self,value):
        self.value = value
        self.next = None

class LinkedList:
    
    def __init__(self, value): # This shows this is a method inside of a class instead of being its own function. 
    # Creates new Node and initializes new LL
        new_node = Node(value)
        self.head = new_node
        self.tail = new_node
        self.length = 1
    
    def append(self,value): # create new Node and add to end
        new_node = Node(value)
        if self.length == 0: #edge case
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node #points current tail to new Node, connecting it to list
            self.tail = new_node #tail now points to last node in LL
        self.length += 1
        return True
    
    def pop_last(self): #pop node from end of list and return it
        if self.length == 0:
            return None
        temp = self.head
        pre = self.head
        while temp.next: #while true, otherwise until we hit None
            pre = temp
            temp = temp.next
        self.tail = pre
        self.tail.next = None
        self.length -= 1
        if self.length == 0:
            self.head = None
            self.tail = None
        return temp
    
    def prepend(self,value):
        new_node = Node(value)
        if self.length == 0: #no guarantee a self.head being None means the LL is empty.
            self.head = new_node
            self.tail = new_node
        else:
            new_node.next = self.head
            self.head = new_node
        self.length += 1
        return True
    
    def pop_first(self):
        if self.length == 0:
            return None
        temp = self.head
        self.head = self.head.next
        temp.next = None
        self.length -= 1
        if self.length == 0:
            self.head = None #redundant 
            self.tail = None
        return temp
    
    def get(self,index):
        if index < 0 or index >= self.length:
            return None #makes sure out of bounds is controlled
        temp = self.head
        for _ in range(index): #underscore when you don't plan to use variable in the loop
            temp = temp.next
        return temp
            
            
    def set_value(self, index, value):
        temp = self.get(index) # you can use a method inside of another of the same class
        if temp: #checking to see if temp is None or True
            temp.value = value
            return True
        return False
        

# Below is a method to print the contents of a Linked List
    def print_list(self):
        temp = self.head
        while temp is not None: #meaning we haven't reached the end
            print(temp.value)
            temp = temp.next
            
my_linked_list = LinkedList(11)
my_linked_list.append(23)
my_linked_list.append(4)
my_linked_list.set_value(1,21)
print(my_linked_list.get(1).value)