def print_items(a,b):
    for i in range(a):
        print(i)

    for j in range(b):
        print(j)

print_items(1, 10)

'''
You cant't just O(n) this program because we have 2 different parameters. The best we can do is O(a + b). 

If the second for loop was nested, we would have to write O(a * b)
'''