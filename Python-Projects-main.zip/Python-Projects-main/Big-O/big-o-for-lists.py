my_list = [11,3,23,7]

my_list.append(17)
'''
This is O(1) because we're just adding 17, which is now my_list[4]
'''

my_list.pop()
'''
This pops out the 17, so the last index. It just removes, so it is O(1) as well.
'''

my_list.pop(0)
 
'''This pops out the first item in the list, which makes the following indexes shift left, so it has to go through the list, which is O(n) AKA Number of items in the list
'''

my_list.insert(0,11)
'''This inserts the 11 we popped back to index 0, which would shift the indexes to the right, going through the list again, which is O(n) AKA Number of items in the list
'''

'''
Adding or Removing at end of list is O(1)
Adding or Removing at front of list is O(n) due to re-indexing

This logic applies as well if we insert/remove in the middle of list, so index 1 or 2. We have to re-index again
'''

'''
If we look up (loop) through the list looking for a value, it's O(n) 

If we access it via index, my_list[3] for example, we go there via memory based on the index, which is O(1)
'''