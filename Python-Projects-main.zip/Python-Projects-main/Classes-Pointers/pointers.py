num1 = 11

num2 = num1

print("Before num2 value is updated:")
print("num1 =", num1)
print("num2 =", num2)

print("\nnum1 points to:", id(num1))# gives address where variable is stored
print("num2 points to:", id(num2)) 

num2 = 22 # does num1 and num2 now point to the same thing or is 22 created somewhere in memory, and num2 points to that?

print("\nAfter num2 value is updated:")
print("num1 =", num1)
print("num2 =", num2) 

print("\nnum1 points to:", id(num1))
print("num2 points to:", id(num2))
#integers are immutable, meaning their position in memory is not changed after it is created.

#####################################


dict1 = {
         'value': 11
        }

dict2 = dict1 

print("\n\nBefore value is updated:")
print("dict1 =", dict1)
print("dict2 =", dict2)

print("\ndict1 points to:", id(dict1))
print("dict2 points to:", id(dict2)) 

dict2['value'] = 22

print("\nAfter value is updated:")
print("dict1 =", dict1)
print("dict2 =", dict2) 

print("\ndict1 points to:", id(dict1))
print("dict2 points to:", id(dict2))

# dictionaries point to the same place, but we can change the value. So the 11 and 22 have the same id in memory, but we can change the 11 to a 22, for example


list1 = [11,3,23,7]
print(id(list1))
