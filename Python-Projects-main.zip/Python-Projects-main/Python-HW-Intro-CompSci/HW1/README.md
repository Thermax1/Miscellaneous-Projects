# HW1

## circle-radius.py

- A simple program in Python that calculates the area of a circle
  - Imported math to get used to importing packages as necessary
