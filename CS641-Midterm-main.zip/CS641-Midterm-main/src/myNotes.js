const myNotes = [];

export default myNotes;
