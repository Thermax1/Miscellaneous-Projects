import React from "react";

function Header() {
  return (
    <div>
      <header>
        <h1>Anthony Munoz Keeper App</h1>
      </header>
    </div>
  );
}

export default Header;
