# CS612-Assignment3-Part1

- In this part, we're implementing a parent class HospitalEmployee.
- There are 3 subclasses called Doctor, Nurse, and Surgeon.
- We're practicing over-riding and extending.

## How to Run
- Run Hospital.java to see results. 
