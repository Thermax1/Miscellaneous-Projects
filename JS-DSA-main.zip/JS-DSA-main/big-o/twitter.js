// Find 1st, find nth

const array = ["hi", "there", "buddy"];

array[0];
array[array.length - 1]; // constant

for(let i )